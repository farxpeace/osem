<?php

return [
	'brand_id' => '<<BRAND_ID>>',
	'api_key' => '<<API_KEY>>',
	'endpoint' => 'https://gate.chip-in.asia/api/v1/',
  'basedUrl' => '<<DOMAIN_URL>>',
  'webhook_public_key' => "<<WEBHOOK_PUBLIC_KEY" // SHOULD BE WRAPPED IN DOUBLE QUOTES (")
];
