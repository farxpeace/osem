<!DOCTYPE html>
  <body>
    <h1>Demo Merchant</h1>

    <span>Sample Actions:</span>
    <ul>
      <li>
        <a href="/api/payment_methods.php" target="_blank">Get Payment Methods</a>
      </li>
      <li>
        <a href="/api/create_purchase.php" target="_blank">Create Checkout</a>
      </li>
      <li>
        <a href="/api/public_key.php" target="_blank">Public Key</a>
      </li>
    </ul>
  </body>
</html>